#!/bin/bash

echo -e "It is OSINT challenge you need to find hidden FLAG from X's social media while gathering information about X\nthe hidden FLAG you will find is encoded using ceasar cipher I advice you to learn about it\nyou can use websites to decode it and of course do not forget to try it with different numbers(ceasar cipher changeable number)\nlastly and most importantly you need to understand that it is the flag when it make sense"

echo -e "you can find accounts in two socail media platforms:instagram and telegram\ninstagram the account name:car_lover75757\ntelegram the public group name is:CarJunkies or type t.me/CarJunkies on google"

