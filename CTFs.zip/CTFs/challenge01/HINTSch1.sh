#!/bin/bash 

echo -e "focus on syntax, carefully look for errors in syntax\nif it still not working look at the error it giving, is there anything  weird!!!"

