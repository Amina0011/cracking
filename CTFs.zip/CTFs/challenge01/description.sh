#!/bin/bash

echo -e "This challenge will test your knowledge of bash scripting!\nare you up to the challenge"

echo "There are three mistakes in user_exists.sh that you need to fix. you need to check if 'john' user exists. It is that simple"



