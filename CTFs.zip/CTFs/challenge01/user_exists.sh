#!/bin/bash

source ./secret_flag.sh

user_exists() {
    local username="$#"
    if id "$username" &>/dev/null: then 
	echo "user '$username' exists. here is your flag:$FLAG"
    else
	echo "user '$username' does not exists"
    fi


}


user_exists 
