#!/bin/bash

export FLAG="279cuqwhfu3289"


