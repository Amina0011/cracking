#! /usr/bin/python
import hashlib

def str_xor(secret, key):
    new_key = key
    i = 0
    while len(new_key) < len(secret):
        new_key = new_key + key[i]
        i = (i + 1) % len(key)
    return "".join([chr(ord(secret_c) ^ ord(new_key_c)) for (secret_c,new_key_c) in zip(secret,new_key)])


flag_enc = open('flag.txt.enc', 'rb').read()
correct_pw_hash = open('pw.hash.bin', 'rb').read()


def hash_pw(pw_str):
    pw_bytes = bytearray()
    pw_bytes.extend(pw_str.encode())
    m = hashlib.md5()
    m.update(pw_bytes)
    return m.digest()


def check():
    user_pw = input("Password for flag: ")
    user_pw_hash = hash_pw(user_pw)

    if( user_pw_hash == correct_pw_hash ):
        print("Your flag:")
        decryption = str_xor(flag_enc.decode(), user_pw)
        print(decryption)
        return
    print("Incorrect!")



check()









#HINT:loop, strip(), chardet will really help you
#HINT:feel free to adopt the file
#Good luck!
